export class Social {
    constructor(public facebook: string, public linkedin: string,
        public twitter: string) {}
}